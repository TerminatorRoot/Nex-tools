function toggleMenu() {
    document.querySelector('.nav-links').classList.toggle('show');
}

function encode() {
    const text = document.getElementById("inputText").value;
    const type = document.getElementById("type").value;
    let result = "";

    switch(type) {

        case "base64":
            result = btoa(text);
            break;

        case "url":
            result = encodeURIComponent(text);
            break;

        case "html":
            result = text.replace(/&/g,"&amp;")
                         .replace(/</g,"&lt;")
                         .replace(/>/g,"&gt;")
                         .replace(/"/g,"&quot;")
                         .replace(/'/g,"&#039;");
            break;

        case "hex":
            result = Array.from(text)
                .map(c => c.charCodeAt(0).toString(16))
                .join(" ");
            break;

        case "binary":
            result = Array.from(text)
                .map(c => c.charCodeAt(0).toString(2).padStart(8,"0"))
                .join(" ");
            break;

        case "ascii":
            result = Array.from(text)
                .map(c => c.charCodeAt(0))
                .join(" ");
            break;

        case "rot13":
            result = text.replace(/[a-zA-Z]/g, function(c){
                return String.fromCharCode(
                    (c <= "Z" ? 90 : 122) >= 
                    (c = c.charCodeAt(0) + 13) ? c : c - 26
                );
            });
            break;
    }

    document.getElementById("outputText").value = result;
}

function decode() {
    const text = document.getElementById("inputText").value;
    const type = document.getElementById("type").value;
    let result = "";

    try {

        switch(type) {

            case "base64":
                result = atob(text);
                break;

            case "url":
                result = decodeURIComponent(text);
                break;

            case "html":
                result = text.replace(/&lt;/g,"<")
                             .replace(/&gt;/g,">")
                             .replace(/&amp;/g,"&")
                             .replace(/&quot;/g,'"')
                             .replace(/&#039;/g,"'");
                break;

            case "hex":
                result = text.split(" ")
                    .map(h => String.fromCharCode(parseInt(h,16)))
                    .join("");
                break;

            case "binary":
                result = text.split(" ")
                    .map(b => String.fromCharCode(parseInt(b,2)))
                    .join("");
                break;

            case "ascii":
                result = text.split(" ")
                    .map(n => String.fromCharCode(parseInt(n)))
                    .join("");
                break;

            case "rot13":
                result = text.replace(/[a-zA-Z]/g, function(c){
                    return String.fromCharCode(
                        (c <= "Z" ? 90 : 122) >= 
                        (c = c.charCodeAt(0) + 13) ? c : c - 26
                    );
                });
                break;
        }

    } catch {
        result = "Invalid input format";
    }

    document.getElementById("outputText").value = result;
}