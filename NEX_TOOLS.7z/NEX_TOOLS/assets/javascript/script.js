function toggleMenu() {
    document.querySelector('.nav-links').classList.toggle('show');
}