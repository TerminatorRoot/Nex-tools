function toggleMenu() {
    document.querySelector('.nav-links').classList.toggle('show');
}

async function generateHash() {
    const text = document.getElementById("inputText").value;
    const algorithm = document.getElementById("algorithm").value;

    const encoder = new TextEncoder();
    const data = encoder.encode(text);
    const hashBuffer = await crypto.subtle.digest(algorithm, data);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');

    document.getElementById("outputHash").value = hashHex;
}